# ABRXOS Builders V1

Incluye dos apps independientes, ambas locales y sin IA integrada:

- **ABRXOS X · Brand Builder V1**: Raw Context + Branding Method (5 Drivers / 25 Tools) + Brand Adapter R6 → AI Brand Package.
- **ABRXOS Content Builder V1**: intención editorial/transcripción + Project Config + Brand Adapter + canon R6 → AI Content Package.

Ejecuta `INSTALAR_AMBAS_APPS.command` para instalar las dos o usa los instaladores individuales.
